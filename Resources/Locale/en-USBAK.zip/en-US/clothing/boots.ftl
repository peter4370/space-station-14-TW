clothing-boots-sidearm = Sidearm
