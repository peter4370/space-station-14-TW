plant-component-plant-success-popup = You plant the {$seedName} {$seedNoun}.
plant-component-already-seeded-popup = The {$name} already has seeds in it!

plant-component-something-already-growing-message = [color=green]{$seedName}[/color] growing here.
plant-component-something-already-growing-low-health-message = The plant looks [color=red]{$healthState}[/color].
plant-component-plant-old-adjective = [color=red]old and wilting[/color]
plant-component-plant-unhealthy-adjective = [color=red]unhealthy[/color]
plant-component-dead-plant-matter-message = It's full of [color=red]dead plant matter[/color].

plant-component-light-improper-warning = The [color=yellow]improper light level alert[/color] is blinking.
plant-component-heat-improper-warning = The [color=orange]improper temperature level alert[/color] is blinking.
plant-component-pressure-improper-warning = The [color=lightblue]improper environment pressure alert[/color] is blinking.
plant-component-gas-missing-warning = The [color=cyan]improper gas environment alert[/color] is blinking.
plant-component-ligneous-cant-harvest-message = The plant is too tough to harvest with your bare hands.
