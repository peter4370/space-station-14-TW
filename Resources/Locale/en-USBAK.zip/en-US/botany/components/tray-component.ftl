tray-component-nothing-planted-message = It has nothing planted in it...
tray-component-water-level-message = Water:     [color=cyan]{$waterLevel}[/color]
tray-component-nutrient-level-message = Nutrient: [color=orange]{$nutritionLevel}[/color]

tray-component-weed-high-level-warning = It's filled with [color=green]weeds[/color]!
tray-component-water-low-warning = The [color=cyan]water[/color] level is [color=red]low[/color]!
tray-component-nutrient-low-warning = The [color=orange]nutrient[/color] level is [color=red]low[/color]!
tray-component-toxin-high-level-warning = The [color=red]toxicity level alert[/color] is flashing red.
tray-component-pest-high-level-warning = It's filled with [color=gray]tiny worms[/color]!
