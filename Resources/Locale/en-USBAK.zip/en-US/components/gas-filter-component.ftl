comp-gas-filter-ui-filter-transfer-rate = Transfer Rate (L/s):
comp-gas-filter-ui-filter-set-rate = Set

comp-gas-filter-ui-filter-gas-current = Currently Filtering:
comp-gas-filter-ui-filter-gas-select = Select a gas to filter out:
comp-gas-filter-ui-filter-gas-confirm = Set Gas
comp-gas-filter-ui-filter-gas-none = None

comp-gas-filter-filtered-gas-examine = It is filtering [color={$statusColor}]{$filteredGas}[/color].
