station-event-breaker-flip-announcement = 根據 { $data } 的資訊，我們已決定停用特定的 APC，以避免設備受損。如需重新啟用這些 APC，請聯絡工程部門。
