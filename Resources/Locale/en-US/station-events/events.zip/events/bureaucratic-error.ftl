station-event-bureaucratic-error-announcement = 有機資源部最近發生的一起行政失誤，可能會導致部分部門人手不足，而其他部門則出現人力過剩的情況。
station-event-clerical-error-announcement = 有機資源部發生了一項輕微的文書錯誤，導致該站的部分記錄遭到永久性毀損。
