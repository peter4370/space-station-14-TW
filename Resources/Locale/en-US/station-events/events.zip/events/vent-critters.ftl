station-event-vent-creatures-start-horde-announcement = 注意。已偵測到大量不明生命體正透過站內的通風系統移動。預計牠們將在 { $location } 附近現身。請立即撤離該區域，以避免人員傷亡。
